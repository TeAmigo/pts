--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: javatest; Type: SCHEMA; Schema: -; Owner: rickcharon
--

CREATE SCHEMA javatest;


ALTER SCHEMA javatest OWNER TO rickcharon;

--
-- Name: sqlj; Type: SCHEMA; Schema: -; Owner: rickcharon
--

CREATE SCHEMA sqlj;


ALTER SCHEMA sqlj OWNER TO rickcharon;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = javatest, pg_catalog;

--
-- Name: _properties; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE _properties AS (
	name character varying(200),
	value character varying(200)
);


ALTER TYPE javatest._properties OWNER TO rickcharon;

--
-- Name: _testsetreturn; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE _testsetreturn AS (
	base integer,
	incbase integer,
	ctime timestamp with time zone
);


ALTER TYPE javatest._testsetreturn OWNER TO rickcharon;

--
-- Name: binarycolumnpair; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE binarycolumnpair AS (
	col1 bytea,
	col2 bytea
);


ALTER TYPE javatest.binarycolumnpair OWNER TO rickcharon;

--
-- Name: complextuple; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE complextuple AS (
	x double precision,
	y double precision
);


ALTER TYPE javatest.complextuple OWNER TO rickcharon;

--
-- Name: metadatabooleans; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE metadatabooleans AS (
	method_name character varying(200),
	result boolean
);


ALTER TYPE javatest.metadatabooleans OWNER TO rickcharon;

--
-- Name: metadataints; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE metadataints AS (
	method_name character varying(200),
	result integer
);


ALTER TYPE javatest.metadataints OWNER TO rickcharon;

--
-- Name: metadatastrings; Type: TYPE; Schema: javatest; Owner: rickcharon
--

CREATE TYPE metadatastrings AS (
	method_name character varying(200),
	result character varying
);


ALTER TYPE javatest.metadatastrings OWNER TO rickcharon;

SET search_path = public, pg_catalog;

--
-- Name: activefuturestype; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE activefuturestype AS (
	symbol character varying(8),
	exchange character varying(8),
	multiplier integer,
	pricemagnifier integer,
	mintick numeric,
	fullname character varying(56),
	mindate timestamp without time zone,
	maxdate timestamp without time zone,
	maxexpiry integer
);


ALTER TYPE public.activefuturestype OWNER TO rickcharon;

--
-- Name: beginendts; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE beginendts AS (
	bt timestamp without time zone,
	et timestamp without time zone
);


ALTER TYPE public.beginendts OWNER TO rickcharon;

--
-- Name: buysellpos; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE buysellpos AS ENUM (
    'BUY',
    'SELL'
);


ALTER TYPE public.buysellpos OWNER TO rickcharon;

--
-- Name: datedrange_type; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE datedrange_type AS (
	datetime timestamp without time zone,
	open numeric,
	high numeric,
	low numeric,
	close numeric,
	volume bigint
);


ALTER TYPE public.datedrange_type OWNER TO rickcharon;

--
-- Name: paperordertype; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE paperordertype AS ENUM (
    'BuyToOpen',
    'SellToOpen',
    'SellProfitToClose',
    'SellLossToClose',
    'BuyProfitToClose',
    'BuyLossToClose'
);


ALTER TYPE public.paperordertype OWNER TO rickcharon;

--
-- Name: plr_environ_type; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE plr_environ_type AS (
	name text,
	value text
);


ALTER TYPE public.plr_environ_type OWNER TO rickcharon;

--
-- Name: r_typename; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE r_typename AS (
	typename text,
	typeoid oid
);


ALTER TYPE public.r_typename OWNER TO rickcharon;

--
-- Name: r_version_type; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE r_version_type AS (
	name text,
	value text
);


ALTER TYPE public.r_version_type OWNER TO rickcharon;

--
-- Name: status; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE status AS ENUM (
    'PendingSubmit',
    'PendingCancel',
    'PreSubmitted',
    'Submitted',
    'Cancelled',
    'Filled',
    'Inactive'
);


ALTER TYPE public.status OWNER TO rickcharon;

--
-- Name: symbolmaxdatelastexpiry; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE symbolmaxdatelastexpiry AS (
	symbol character varying(8),
	maxdate timestamp without time zone,
	maxexpiry integer
);


ALTER TYPE public.symbolmaxdatelastexpiry OWNER TO rickcharon;

--
-- Name: symbolminmaxdates; Type: TYPE; Schema: public; Owner: rickcharon
--

CREATE TYPE symbolminmaxdates AS (
	symbol character varying,
	mindate timestamp without time zone,
	maxdate timestamp without time zone
);


ALTER TYPE public.symbolminmaxdates OWNER TO rickcharon;

SET search_path = javatest, pg_catalog;

--
-- Name: complexdummy(cstring); Type: FUNCTION; Schema: javatest; Owner: rickcharon
--

CREATE FUNCTION complexdummy(cstring) RETURNS complex
    LANGUAGE internal
    AS $$lower$$;


ALTER FUNCTION javatest.complexdummy(cstring) OWNER TO rickcharon;

SET search_path = public, pg_catalog;

--
-- Name: activefuturesdetails(); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION activefuturesdetails() RETURNS SETOF activefuturestype
    LANGUAGE sql
    AS $$
  SELECT fc.symbol, fc.exchange, fc.multiplier, fc.priceMagnifier, fc.mintick, fc.fullname,
       qm.minDate, qm.maxDate, qm.maxActiveExpiry
  FROM (SELECT distinct  symbol, exchange, multiplier,
                         priceMagnifier, mintick,
                         fullName FROM futuresContractDetails) as fc,
       (SELECT symbol, min(datetime) as minDate, max(datetime) as maxDate,
          max(expiry) as maxActiveExpiry FROM quotes1min
         group by symbol) as qm where qm.symbol = fc.symbol;
$$;


ALTER FUNCTION public.activefuturesdetails() OWNER TO rickcharon;

--
-- Name: add1(integer); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION add1(INOUT ain integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
   DECLARE ii integer;
   BEGIN
      ain = ain + 1;
      return;
   END;
   $$;


ALTER FUNCTION public.add1(INOUT ain integer) OWNER TO rickcharon;

--
-- Name: add2(integer); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION add2(ain integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
   DECLARE ii integer;
   BEGIN
      ii = ain;
      perform add1(ii);
      return ii;
   END;
   $$;


ALTER FUNCTION public.add2(ain integer) OWNER TO rickcharon;

--
-- Name: addone(integer); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION addone(testint integer) RETURNS integer
    LANGUAGE sql
    AS $_$
   select 1 + $1;
   $_$;


ALTER FUNCTION public.addone(testint integer) OWNER TO rickcharon;

--
-- Name: compressrows(character varying, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION compressrows(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, OUT retrow datedrange_type) RETURNS datedrange_type
    LANGUAGE plpgsql
    AS $$
 DECLARE
    tmpRow datedRange_type%ROWTYPE;
    curs1 refcursor;
    BEGIN
       OPEN curs1 SCROLL FOR EXECUTE 
          'SELECT datetime, open, high, low, close, volume FROM quotes1min
          where symbol= ''' || sym || ''' and datetime >= ''' || beginTime || ''' and datetime < '''
          || endTime || ''' order by datetime';
       FETCH curs1 INTO retRow;
       LOOP
          FETCH curs1 INTO tmpRow;
          if not found then
             exit ;
          end if;
          if tmpRow.high > retRow.high then
             retRow.high = tmpRow.high;
             end if;
          if tmpRow.low < retRow.low then
             retRow.low = tmpRow.low;
             end if;
          retRow.volume = retRow.volume + tmpRow.volume;
          retRow."close" = tmpRow."close";
          end loop;
    END
$$;


ALTER FUNCTION public.compressrows(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, OUT retrow datedrange_type) OWNER TO rickcharon;

--
-- Name: createcompressedtable(character varying, timestamp without time zone, timestamp without time zone, integer); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION createcompressedtable(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, compressionfactor integer) RETURNS SETOF datedrange_type
    LANGUAGE plpgsql
    AS $$
DECLARE
   retrow datedRange_type;
   curs1 refcursor;
   beginDateTime timestamp;
   endDateTime timestamp;
BEGIN
    OPEN curs1 SCROLL FOR EXECUTE 'SELECT CAST(generate_series(CAST(''' || beginTime || ''' As timestamp), 
    CAST(''' || endTime || ''' As timestamp), ''' || compressionFactor || ' minutes'') as timestamp)';
    FETCH curs1 INTO beginDateTime;
    LOOP
       FETCH curs1 INTO endDateTime;
       if not found then
          exit ;
       end if;
      select * into retrow from compressRows(sym, beginDateTime, endDateTime);
      beginDateTime = endDateTime;
      RETURN NEXT retrow;
    END LOOP;
    RETURN;
END;
$$;


ALTER FUNCTION public.createcompressedtable(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, compressionfactor integer) OWNER TO rickcharon;

--
-- Name: createcompressedtimeseries(timestamp without time zone, timestamp without time zone, integer); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION createcompressedtimeseries(begintime timestamp without time zone, endtime timestamp without time zone, compressionfactor integer) RETURNS SETOF timestamp without time zone
    LANGUAGE plpgsql
    AS $$
DECLARE
   retrow timestamp;
BEGIN   
   FOR retRow in EXECUTE 'SELECT CAST(generate_series(CAST(''' || beginTime || ''' As timestamp), 
    CAST(''' || endTime || ''' As timestamp), ''' || compressionFactor || ' minutes'') as timestamp)' LOOP
      RETURN NEXT retRow;
   END LOOP;
   RETURN;
END;
$$;


ALTER FUNCTION public.createcompressedtimeseries(begintime timestamp without time zone, endtime timestamp without time zone, compressionfactor integer) OWNER TO rickcharon;

--
-- Name: datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) RETURNS SETOF datedrange_type
    LANGUAGE sql
    AS $_$
SELECT datetime, open, high, low, close, volume FROM quotes1min
WHERE symbol = $1 and datetime >= $2 and datetime <= $3
ORDER BY datetime;
$_$;


ALTER FUNCTION public.datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) OWNER TO rickcharon;

--
-- Name: distinctquotesymbols(); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION distinctquotesymbols() RETURNS TABLE(symbol text)
    LANGUAGE sql
    AS $$ select distinct symbol from quotes1min order by symbol;
$$;


ALTER FUNCTION public.distinctquotesymbols() OWNER TO rickcharon;

--
-- Name: minmaxdateforall(); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION minmaxdateforall() RETURNS SETOF symbolminmaxdates
    LANGUAGE sql
    AS $$
  SELECT symbol, min(datetime) as minDate, max(datetime) as maxDate
    FROM quotes1min group by symbol order by symbol;
$$;


ALTER FUNCTION public.minmaxdateforall() OWNER TO rickcharon;

--
-- Name: playitforward(character varying, timestamp without time zone, numeric, numeric); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION playitforward(character varying, timestamp without time zone, numeric, numeric) RETURNS datedrange_type
    LANGUAGE sql
    AS $_$
  SELECT datetime, open, high, low, close, volume FROM quotes1min
   where symbol= $1 and datetime > $2 and (high >= $3 or low <=  $4) order by
   datetime limit 1;
$_$;


ALTER FUNCTION public.playitforward(character varying, timestamp without time zone, numeric, numeric) OWNER TO rickcharon;

--
-- Name: playitforward2(character varying, timestamp without time zone, numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION playitforward2(symbol character varying, begindt timestamp without time zone, entryprice numeric, hightarget numeric, lowtarget numeric) RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $$
DECLARE
   tmpRow datedRange_type%ROWTYPE;
   BEGIN
      select * into tmpRow from playitforward('AUD', '2010-01-03', 0.90, 0.88);
      return tmpRow.datetime; --query select enteredindb from papertrades;
   END;
$$;


ALTER FUNCTION public.playitforward2(symbol character varying, begindt timestamp without time zone, entryprice numeric, hightarget numeric, lowtarget numeric) OWNER TO rickcharon;

--
-- Name: reffunc(refcursor); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION reffunc(refcursor) RETURNS refcursor
    LANGUAGE plpgsql
    AS $_$
BEGIN
    OPEN $1 FOR SELECT col FROM test;
    RETURN $1;
END;
$_$;


ALTER FUNCTION public.reffunc(refcursor) OWNER TO rickcharon;

--
-- Name: symbolmaxdatelastexpirylist(); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION symbolmaxdatelastexpirylist() RETURNS SETOF symbolmaxdatelastexpiry
    LANGUAGE sql
    AS $$
  SELECT symbol,max(datetime) as maxDate, max(expiry)
      as maxExpiry FROM quotes1min group by symbol order by maxExpiry;
$$;


ALTER FUNCTION public.symbolmaxdatelastexpirylist() OWNER TO rickcharon;

--
-- Name: tt_compressrows(character varying, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: rickcharon
--

CREATE FUNCTION tt_compressrows(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, OUT retrow datedrange_type) RETURNS datedrange_type
    LANGUAGE plpgsql
    AS $$
 DECLARE
    tmpRow datedRange_type%ROWTYPE;
    curs1 refcursor;
    BEGIN
       OPEN curs1 SCROLL FOR EXECUTE 
          'SELECT datetime, open, high, low, close, volume FROM quotes1min
          where symbol= ''' || sym || ''' and datetime >= ''' || beginTime || ''' and datetime < '''
          || endTime || ''' order by datetime';
       FETCH curs1 INTO retRow;
       retRow."open" = 1;
       LOOP
          FETCH curs1 INTO tmpRow;
          if not found then
             exit ;
          end if;
          if tmpRow.high > retRow.high then
             retRow.high = tmpRow.high;
             end if;
          if tmpRow.low < retRow.low then
             retRow.low = tmpRow.low;
             end if;
          retRow.volume = retRow.volume + tmpRow.volume;
          
          end loop;
    END
$$;


ALTER FUNCTION public.tt_compressrows(sym character varying, begintime timestamp without time zone, endtime timestamp without time zone, OUT retrow datedrange_type) OWNER TO rickcharon;

SET search_path = javatest, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: employees1; Type: TABLE; Schema: javatest; Owner: rickcharon; Tablespace: 
--

CREATE TABLE employees1 (
    id integer NOT NULL,
    name character varying(200),
    salary integer
);


ALTER TABLE javatest.employees1 OWNER TO rickcharon;

--
-- Name: employees2; Type: TABLE; Schema: javatest; Owner: rickcharon; Tablespace: 
--

CREATE TABLE employees2 (
    id integer NOT NULL,
    name character varying(200),
    salary integer,
    transferday date,
    transfertime time without time zone
);


ALTER TABLE javatest.employees2 OWNER TO rickcharon;

--
-- Name: mdt; Type: TABLE; Schema: javatest; Owner: rickcharon; Tablespace: 
--

CREATE TABLE mdt (
    id integer,
    idesc text,
    moddate timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE javatest.mdt OWNER TO rickcharon;

SET default_with_oids = true;

--
-- Name: username_test; Type: TABLE; Schema: javatest; Owner: rickcharon; Tablespace: 
--

CREATE TABLE username_test (
    name text,
    username text NOT NULL
);


ALTER TABLE javatest.username_test OWNER TO rickcharon;

SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- Name: futurescontractdetails; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE futurescontractdetails (
    symbol character varying(8) NOT NULL,
    expiry integer NOT NULL,
    multiplier integer NOT NULL,
    pricemagnifier integer NOT NULL,
    exchange character varying(8) NOT NULL,
    mintick numeric NOT NULL,
    begindate date DEFAULT '1900-01-01'::date NOT NULL,
    enddate date DEFAULT '1900-01-01'::date NOT NULL,
    active bit(1) DEFAULT B'0'::"bit" NOT NULL,
    fullname character varying(56) NOT NULL
);


ALTER TABLE public.futurescontractdetails OWNER TO rickcharon;

--
-- Name: ibcard; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE ibcard (
    num integer NOT NULL,
    code character varying(4) NOT NULL
);


ALTER TABLE public.ibcard OWNER TO rickcharon;

--
-- Name: paperorders_idx_seq; Type: SEQUENCE; Schema: public; Owner: rickcharon
--

CREATE SEQUENCE paperorders_idx_seq
    START WITH 7
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paperorders_idx_seq OWNER TO rickcharon;

--
-- Name: paperorders; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE paperorders (
    idx integer DEFAULT nextval('paperorders_idx_seq'::regclass) NOT NULL,
    ul character varying(12) NOT NULL,
    ordertype paperordertype NOT NULL,
    price numeric DEFAULT (0)::numeric NOT NULL,
    translatedprice numeric DEFAULT (0)::numeric NOT NULL,
    bartime timestamp without time zone NOT NULL,
    lossorgain numeric DEFAULT (0)::numeric NOT NULL,
    orderid integer NOT NULL,
    parentid integer,
    entrytimestamp timestamp without time zone NOT NULL
);


ALTER TABLE public.paperorders OWNER TO rickcharon;

--
-- Name: paperorders-orig; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE "paperorders-orig" (
    idx integer DEFAULT nextval('paperorders_idx_seq'::regclass) NOT NULL,
    ul character varying(12) NOT NULL,
    expiry integer NOT NULL,
    buysell character varying(8) NOT NULL,
    totalquantity integer DEFAULT 0 NOT NULL,
    filledquantity integer DEFAULT 0 NOT NULL,
    remainingquantity integer DEFAULT 0,
    limitprice numeric DEFAULT (0)::numeric NOT NULL,
    auxprice numeric DEFAULT (0)::numeric NOT NULL,
    avgfillprice numeric DEFAULT (0)::numeric NOT NULL,
    ordertype character varying(8) NOT NULL,
    tif character varying(8) NOT NULL,
    translatedprice numeric NOT NULL,
    bartime timestamp without time zone NOT NULL,
    lossorgain numeric,
    ocagroup character varying(24) DEFAULT NULL::character varying,
    ocatype smallint DEFAULT (2)::smallint,
    orderid integer NOT NULL,
    parentid integer,
    permid integer,
    entrytimestamp timestamp without time zone NOT NULL,
    executedtimestamp timestamp without time zone,
    status status DEFAULT 'PendingSubmit'::status NOT NULL
);


ALTER TABLE public."paperorders-orig" OWNER TO rickcharon;

--
-- Name: papertrades_id_seq; Type: SEQUENCE; Schema: public; Owner: rickcharon
--

CREATE SEQUENCE papertrades_id_seq
    START WITH 3
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.papertrades_id_seq OWNER TO rickcharon;

--
-- Name: papertrades; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE papertrades (
    id integer DEFAULT nextval('papertrades_id_seq'::regclass) NOT NULL,
    enteredindb timestamp without time zone DEFAULT now() NOT NULL,
    begintradedatetime timestamp without time zone NOT NULL,
    symbol character varying(12) NOT NULL,
    "position" buysellpos NOT NULL,
    entry numeric NOT NULL,
    stoploss numeric NOT NULL,
    stoprisk numeric NOT NULL,
    stopprofit numeric NOT NULL,
    profitpotential numeric NOT NULL,
    outcome numeric NOT NULL,
    exittradedatetime timestamp without time zone NOT NULL
);


ALTER TABLE public.papertrades OWNER TO rickcharon;

--
-- Name: qtest; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE qtest (
    symbol character varying(15),
    expiry integer,
    datetime timestamp without time zone,
    open numeric,
    high numeric,
    low numeric,
    close numeric,
    volume bigint,
    weeknumber integer
);


ALTER TABLE public.qtest OWNER TO rickcharon;

--
-- Name: quotes1min; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE quotes1min (
    symbol character varying(15) NOT NULL,
    expiry integer NOT NULL,
    datetime timestamp without time zone NOT NULL,
    open numeric NOT NULL,
    high numeric NOT NULL,
    low numeric NOT NULL,
    close numeric NOT NULL,
    volume bigint NOT NULL
);


ALTER TABLE public.quotes1min OWNER TO rickcharon;

--
-- Name: quotes1minags; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE quotes1minags (
    symbol character varying(15) NOT NULL,
    expiry integer NOT NULL,
    datetime timestamp without time zone NOT NULL,
    open numeric NOT NULL,
    high numeric NOT NULL,
    low numeric NOT NULL,
    close numeric NOT NULL,
    volume bigint NOT NULL
);


ALTER TABLE public.quotes1minags OWNER TO rickcharon;

--
-- Name: quotes1mindx; Type: TABLE; Schema: public; Owner: trader1; Tablespace: 
--

CREATE TABLE quotes1mindx (
    symbol character varying(15),
    expiry integer,
    datetime timestamp without time zone,
    open numeric,
    high numeric,
    low numeric,
    close numeric,
    volume bigint
);


ALTER TABLE public.quotes1mindx OWNER TO trader1;

--
-- Name: quotes1minenergy; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE quotes1minenergy (
    symbol character varying(15) NOT NULL,
    expiry integer NOT NULL,
    datetime timestamp without time zone NOT NULL,
    open numeric NOT NULL,
    high numeric NOT NULL,
    low numeric NOT NULL,
    close numeric NOT NULL,
    volume bigint NOT NULL
);


ALTER TABLE public.quotes1minenergy OWNER TO rickcharon;

--
-- Name: quotes1minpulled; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE quotes1minpulled (
    symbol character varying(15) NOT NULL,
    expiry integer NOT NULL,
    datetime timestamp without time zone NOT NULL,
    open numeric NOT NULL,
    high numeric NOT NULL,
    low numeric NOT NULL,
    close numeric NOT NULL,
    volume bigint NOT NULL
);


ALTER TABLE public.quotes1minpulled OWNER TO rickcharon;

--
-- Name: test; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE test (
    col text
);


ALTER TABLE public.test OWNER TO rickcharon;

--
-- Name: trades-obsolete; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE "trades-obsolete" (
    ul character varying(12) NOT NULL,
    expiry integer NOT NULL,
    buysell character varying(8) NOT NULL,
    quantity integer NOT NULL,
    price numeric NOT NULL,
    type character varying(8) NOT NULL,
    tif character varying(8) NOT NULL,
    translatedprice numeric NOT NULL,
    bartime timestamp without time zone NOT NULL,
    lossorgain numeric,
    ocagroup character varying(24) DEFAULT NULL::character varying,
    orderid integer NOT NULL,
    parentid integer,
    permid integer,
    entrydatetime timestamp without time zone NOT NULL
);


ALTER TABLE public."trades-obsolete" OWNER TO rickcharon;

--
-- Name: tradesSentToIB; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE "tradesSentToIB" (
    id integer DEFAULT nextval('papertrades_id_seq'::regclass) NOT NULL,
    enteredindb timestamp without time zone DEFAULT now() NOT NULL,
    begintradedatetime timestamp without time zone NOT NULL,
    symbol character varying(12) NOT NULL,
    "position" buysellpos NOT NULL,
    entry numeric NOT NULL,
    stoploss numeric NOT NULL,
    stoprisk numeric NOT NULL,
    stopprofit numeric NOT NULL,
    profitpotential numeric NOT NULL,
    outcome numeric NOT NULL,
    exittradedatetime timestamp without time zone NOT NULL
);


ALTER TABLE public."tradesSentToIB" OWNER TO rickcharon;

--
-- Name: tradesandresults; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE tradesandresults (
    indatetime timestamp without time zone NOT NULL,
    symbol character varying(12) NOT NULL,
    "position" character varying(12) NOT NULL,
    entry numeric,
    stoploss numeric,
    stoprisk numeric,
    stopprofit numeric,
    profitpotential numeric,
    outcome numeric,
    outdatetime timestamp without time zone
);


ALTER TABLE public.tradesandresults OWNER TO rickcharon;

--
-- Name: tt; Type: TABLE; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE TABLE tt (
    date_part double precision
);


ALTER TABLE public.tt OWNER TO rickcharon;

SET search_path = sqlj, pg_catalog;

--
-- Name: classpath_entry; Type: TABLE; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

CREATE TABLE classpath_entry (
    schemaname character varying(30) NOT NULL,
    ordinal smallint NOT NULL,
    jarid integer NOT NULL
);


ALTER TABLE sqlj.classpath_entry OWNER TO rickcharon;

--
-- Name: jar_entry; Type: TABLE; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

CREATE TABLE jar_entry (
    entryid integer NOT NULL,
    entryname character varying(200) NOT NULL,
    jarid integer NOT NULL,
    entryimage bytea NOT NULL
);


ALTER TABLE sqlj.jar_entry OWNER TO rickcharon;

--
-- Name: jar_entry_entryid_seq; Type: SEQUENCE; Schema: sqlj; Owner: rickcharon
--

CREATE SEQUENCE jar_entry_entryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sqlj.jar_entry_entryid_seq OWNER TO rickcharon;

--
-- Name: jar_entry_entryid_seq; Type: SEQUENCE OWNED BY; Schema: sqlj; Owner: rickcharon
--

ALTER SEQUENCE jar_entry_entryid_seq OWNED BY jar_entry.entryid;


--
-- Name: jar_repository; Type: TABLE; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

CREATE TABLE jar_repository (
    jarid integer NOT NULL,
    jarname character varying(100) NOT NULL,
    jarorigin character varying(500) NOT NULL,
    jarowner name NOT NULL,
    jarmanifest text,
    deploymentdesc integer
);


ALTER TABLE sqlj.jar_repository OWNER TO rickcharon;

--
-- Name: jar_repository_jarid_seq; Type: SEQUENCE; Schema: sqlj; Owner: rickcharon
--

CREATE SEQUENCE jar_repository_jarid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sqlj.jar_repository_jarid_seq OWNER TO rickcharon;

--
-- Name: jar_repository_jarid_seq; Type: SEQUENCE OWNED BY; Schema: sqlj; Owner: rickcharon
--

ALTER SEQUENCE jar_repository_jarid_seq OWNED BY jar_repository.jarid;


--
-- Name: typemap_entry; Type: TABLE; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

CREATE TABLE typemap_entry (
    mapid integer NOT NULL,
    javaname character varying(200) NOT NULL,
    sqlname name NOT NULL
);


ALTER TABLE sqlj.typemap_entry OWNER TO rickcharon;

--
-- Name: typemap_entry_mapid_seq; Type: SEQUENCE; Schema: sqlj; Owner: rickcharon
--

CREATE SEQUENCE typemap_entry_mapid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sqlj.typemap_entry_mapid_seq OWNER TO rickcharon;

--
-- Name: typemap_entry_mapid_seq; Type: SEQUENCE OWNED BY; Schema: sqlj; Owner: rickcharon
--

ALTER SEQUENCE typemap_entry_mapid_seq OWNED BY typemap_entry.mapid;


--
-- Name: entryid; Type: DEFAULT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY jar_entry ALTER COLUMN entryid SET DEFAULT nextval('jar_entry_entryid_seq'::regclass);


--
-- Name: jarid; Type: DEFAULT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY jar_repository ALTER COLUMN jarid SET DEFAULT nextval('jar_repository_jarid_seq'::regclass);


--
-- Name: mapid; Type: DEFAULT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY typemap_entry ALTER COLUMN mapid SET DEFAULT nextval('typemap_entry_mapid_seq'::regclass);


SET search_path = javatest, pg_catalog;

--
-- Name: employees1_pkey; Type: CONSTRAINT; Schema: javatest; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY employees1
    ADD CONSTRAINT employees1_pkey PRIMARY KEY (id);


--
-- Name: employees2_pkey; Type: CONSTRAINT; Schema: javatest; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY employees2
    ADD CONSTRAINT employees2_pkey PRIMARY KEY (id);


SET search_path = public, pg_catalog;

--
-- Name: futurescontractdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY futurescontractdetails
    ADD CONSTRAINT futurescontractdetails_pkey PRIMARY KEY (symbol, expiry);


--
-- Name: ibcard_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY ibcard
    ADD CONSTRAINT ibcard_pkey PRIMARY KEY (num);


--
-- Name: paperorders_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY paperorders
    ADD CONSTRAINT paperorders_pkey PRIMARY KEY (idx);


--
-- Name: papertrades_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY papertrades
    ADD CONSTRAINT papertrades_pkey PRIMARY KEY (id);


--
-- Name: quotes1min_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY quotes1min
    ADD CONSTRAINT quotes1min_pkey PRIMARY KEY (symbol, datetime);


--
-- Name: quotes1minags_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY quotes1minags
    ADD CONSTRAINT quotes1minags_pkey PRIMARY KEY (symbol, datetime);


--
-- Name: quotes1minenergy_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY quotes1minenergy
    ADD CONSTRAINT quotes1minenergy_pkey PRIMARY KEY (symbol, datetime);


--
-- Name: quotes1mininterestrates_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY quotes1minpulled
    ADD CONSTRAINT quotes1mininterestrates_pkey PRIMARY KEY (symbol, datetime);


--
-- Name: tradesSentToIB_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY "tradesSentToIB"
    ADD CONSTRAINT "tradesSentToIB_pkey" PRIMARY KEY (id);


--
-- Name: trades_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY "trades-obsolete"
    ADD CONSTRAINT trades_pkey PRIMARY KEY (ul, expiry, entrydatetime);


--
-- Name: tradesandresults_pkey; Type: CONSTRAINT; Schema: public; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY tradesandresults
    ADD CONSTRAINT tradesandresults_pkey PRIMARY KEY (indatetime, symbol);


SET search_path = sqlj, pg_catalog;

--
-- Name: classpath_entry_pkey; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY classpath_entry
    ADD CONSTRAINT classpath_entry_pkey PRIMARY KEY (schemaname, ordinal);


--
-- Name: jar_entry_jarid_key; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY jar_entry
    ADD CONSTRAINT jar_entry_jarid_key UNIQUE (jarid, entryname);


--
-- Name: jar_entry_pkey; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY jar_entry
    ADD CONSTRAINT jar_entry_pkey PRIMARY KEY (entryid);


--
-- Name: jar_repository_jarname_key; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY jar_repository
    ADD CONSTRAINT jar_repository_jarname_key UNIQUE (jarname);


--
-- Name: jar_repository_pkey; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY jar_repository
    ADD CONSTRAINT jar_repository_pkey PRIMARY KEY (jarid);


--
-- Name: typemap_entry_pkey; Type: CONSTRAINT; Schema: sqlj; Owner: rickcharon; Tablespace: 
--

ALTER TABLE ONLY typemap_entry
    ADD CONSTRAINT typemap_entry_pkey PRIMARY KEY (mapid);


SET search_path = public, pg_catalog;

--
-- Name: Primary key; Type: INDEX; Schema: public; Owner: rickcharon; Tablespace: 
--

CREATE UNIQUE INDEX "Primary key" ON qtest USING btree (symbol, datetime);


--
-- Name: replace_futuresContractDetails; Type: RULE; Schema: public; Owner: rickcharon
--

CREATE RULE "replace_futuresContractDetails" AS
    ON INSERT TO futurescontractdetails
   WHERE (EXISTS ( SELECT 1
           FROM futurescontractdetails futurescontractdetails_1
          WHERE (((futurescontractdetails_1.symbol)::text = (new.symbol)::text) AND (futurescontractdetails_1.expiry = new.expiry)))) DO INSTEAD  UPDATE futurescontractdetails SET multiplier = new.multiplier, pricemagnifier = new.pricemagnifier, exchange = new.exchange, mintick = new.mintick, fullname = new.fullname
  WHERE (((futurescontractdetails.symbol)::text = (new.symbol)::text) AND (futurescontractdetails.expiry = new.expiry));


--
-- Name: replace_qtest; Type: RULE; Schema: public; Owner: rickcharon
--

CREATE RULE replace_qtest AS
    ON INSERT TO qtest
   WHERE (EXISTS ( SELECT 1
           FROM qtest qtest_1
          WHERE (((qtest_1.symbol)::text = (new.symbol)::text) AND (qtest_1.datetime = new.datetime)))) DO INSTEAD  UPDATE qtest SET expiry = new.expiry, open = new.open, high = new.high, low = new.low, close = new.close, volume = new.volume
  WHERE (((qtest.symbol)::text = (new.symbol)::text) AND (qtest.datetime = new.datetime));


--
-- Name: replace_quotes1min; Type: RULE; Schema: public; Owner: rickcharon
--

CREATE RULE replace_quotes1min AS
    ON INSERT TO quotes1min
   WHERE (EXISTS ( SELECT 1
           FROM quotes1min quotes1min_1
          WHERE (((quotes1min_1.symbol)::text = (new.symbol)::text) AND (quotes1min_1.datetime = new.datetime)))) DO INSTEAD  UPDATE quotes1min SET expiry = new.expiry, open = new.open, high = new.high, low = new.low, close = new.close, volume = new.volume
  WHERE (((quotes1min.symbol)::text = (new.symbol)::text) AND (quotes1min.datetime = new.datetime));


--
-- Name: replace_quotes1mininterestrates; Type: RULE; Schema: public; Owner: rickcharon
--

CREATE RULE replace_quotes1mininterestrates AS
    ON INSERT TO quotes1min
   WHERE (EXISTS ( SELECT 1
           FROM quotes1min quotes1min_1
          WHERE (((quotes1min_1.symbol)::text = (new.symbol)::text) AND (quotes1min_1.datetime = new.datetime)))) DO INSTEAD  UPDATE quotes1min SET expiry = new.expiry, open = new.open, high = new.high, low = new.low, close = new.close, volume = new.volume
  WHERE (((quotes1min.symbol)::text = (new.symbol)::text) AND (quotes1min.datetime = new.datetime));


SET search_path = sqlj, pg_catalog;

--
-- Name: classpath_entry_jarid_fkey; Type: FK CONSTRAINT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY classpath_entry
    ADD CONSTRAINT classpath_entry_jarid_fkey FOREIGN KEY (jarid) REFERENCES jar_repository(jarid) ON DELETE CASCADE;


--
-- Name: jar_entry_jarid_fkey; Type: FK CONSTRAINT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY jar_entry
    ADD CONSTRAINT jar_entry_jarid_fkey FOREIGN KEY (jarid) REFERENCES jar_repository(jarid) ON DELETE CASCADE;


--
-- Name: jar_repository_deploymentdesc_fkey; Type: FK CONSTRAINT; Schema: sqlj; Owner: rickcharon
--

ALTER TABLE ONLY jar_repository
    ADD CONSTRAINT jar_repository_deploymentdesc_fkey FOREIGN KEY (deploymentdesc) REFERENCES jar_entry(entryid) ON DELETE SET NULL;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: sqlj; Type: ACL; Schema: -; Owner: rickcharon
--

REVOKE ALL ON SCHEMA sqlj FROM PUBLIC;
REVOKE ALL ON SCHEMA sqlj FROM rickcharon;
GRANT ALL ON SCHEMA sqlj TO rickcharon;
GRANT USAGE ON SCHEMA sqlj TO PUBLIC;


SET search_path = javatest, pg_catalog;

--
-- Name: _properties; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE _properties FROM PUBLIC;
REVOKE ALL ON TYPE _properties FROM rickcharon;
GRANT ALL ON TYPE _properties TO PUBLIC;


--
-- Name: _testsetreturn; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE _testsetreturn FROM PUBLIC;
REVOKE ALL ON TYPE _testsetreturn FROM rickcharon;
GRANT ALL ON TYPE _testsetreturn TO PUBLIC;


--
-- Name: binarycolumnpair; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE binarycolumnpair FROM PUBLIC;
REVOKE ALL ON TYPE binarycolumnpair FROM rickcharon;
GRANT ALL ON TYPE binarycolumnpair TO PUBLIC;


--
-- Name: complextuple; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE complextuple FROM PUBLIC;
REVOKE ALL ON TYPE complextuple FROM rickcharon;
GRANT ALL ON TYPE complextuple TO PUBLIC;


--
-- Name: metadatabooleans; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE metadatabooleans FROM PUBLIC;
REVOKE ALL ON TYPE metadatabooleans FROM rickcharon;
GRANT ALL ON TYPE metadatabooleans TO PUBLIC;


--
-- Name: metadataints; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE metadataints FROM PUBLIC;
REVOKE ALL ON TYPE metadataints FROM rickcharon;
GRANT ALL ON TYPE metadataints TO PUBLIC;


--
-- Name: metadatastrings; Type: ACL; Schema: javatest; Owner: rickcharon
--

REVOKE ALL ON TYPE metadatastrings FROM PUBLIC;
REVOKE ALL ON TYPE metadatastrings FROM rickcharon;
GRANT ALL ON TYPE metadatastrings TO PUBLIC;


SET search_path = public, pg_catalog;

--
-- Name: activefuturestype; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE activefuturestype FROM PUBLIC;
REVOKE ALL ON TYPE activefuturestype FROM rickcharon;
GRANT ALL ON TYPE activefuturestype TO PUBLIC;


--
-- Name: beginendts; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE beginendts FROM PUBLIC;
REVOKE ALL ON TYPE beginendts FROM rickcharon;
GRANT ALL ON TYPE beginendts TO PUBLIC;


--
-- Name: buysellpos; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE buysellpos FROM PUBLIC;
REVOKE ALL ON TYPE buysellpos FROM rickcharon;
GRANT ALL ON TYPE buysellpos TO PUBLIC;


--
-- Name: datedrange_type; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE datedrange_type FROM PUBLIC;
REVOKE ALL ON TYPE datedrange_type FROM rickcharon;
GRANT ALL ON TYPE datedrange_type TO PUBLIC;


--
-- Name: paperordertype; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE paperordertype FROM PUBLIC;
REVOKE ALL ON TYPE paperordertype FROM rickcharon;
GRANT ALL ON TYPE paperordertype TO PUBLIC;


--
-- Name: plr_environ_type; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE plr_environ_type FROM PUBLIC;
REVOKE ALL ON TYPE plr_environ_type FROM rickcharon;
GRANT ALL ON TYPE plr_environ_type TO PUBLIC;


--
-- Name: r_typename; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE r_typename FROM PUBLIC;
REVOKE ALL ON TYPE r_typename FROM rickcharon;
GRANT ALL ON TYPE r_typename TO PUBLIC;


--
-- Name: r_version_type; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE r_version_type FROM PUBLIC;
REVOKE ALL ON TYPE r_version_type FROM rickcharon;
GRANT ALL ON TYPE r_version_type TO PUBLIC;


--
-- Name: status; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE status FROM PUBLIC;
REVOKE ALL ON TYPE status FROM rickcharon;
GRANT ALL ON TYPE status TO PUBLIC;


--
-- Name: symbolmaxdatelastexpiry; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE symbolmaxdatelastexpiry FROM PUBLIC;
REVOKE ALL ON TYPE symbolmaxdatelastexpiry FROM rickcharon;
GRANT ALL ON TYPE symbolmaxdatelastexpiry TO PUBLIC;


--
-- Name: symbolminmaxdates; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TYPE symbolminmaxdates FROM PUBLIC;
REVOKE ALL ON TYPE symbolminmaxdates FROM rickcharon;
GRANT ALL ON TYPE symbolminmaxdates TO PUBLIC;


--
-- Name: datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone); Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON FUNCTION datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) FROM PUBLIC;
REVOKE ALL ON FUNCTION datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) FROM rickcharon;
GRANT ALL ON FUNCTION datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) TO rickcharon;
GRANT ALL ON FUNCTION datedrangebysymbol(character varying, timestamp without time zone, timestamp without time zone) TO PUBLIC;


--
-- Name: distinctquotesymbols(); Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON FUNCTION distinctquotesymbols() FROM PUBLIC;
REVOKE ALL ON FUNCTION distinctquotesymbols() FROM rickcharon;
GRANT ALL ON FUNCTION distinctquotesymbols() TO rickcharon;
GRANT ALL ON FUNCTION distinctquotesymbols() TO PUBLIC;


--
-- Name: quotes1min; Type: ACL; Schema: public; Owner: rickcharon
--

REVOKE ALL ON TABLE quotes1min FROM PUBLIC;
REVOKE ALL ON TABLE quotes1min FROM rickcharon;
GRANT ALL ON TABLE quotes1min TO rickcharon;
GRANT ALL ON TABLE quotes1min TO trader1;


SET search_path = sqlj, pg_catalog;

--
-- Name: classpath_entry; Type: ACL; Schema: sqlj; Owner: rickcharon
--

REVOKE ALL ON TABLE classpath_entry FROM PUBLIC;
REVOKE ALL ON TABLE classpath_entry FROM rickcharon;
GRANT ALL ON TABLE classpath_entry TO rickcharon;
GRANT SELECT ON TABLE classpath_entry TO PUBLIC;


--
-- Name: jar_entry; Type: ACL; Schema: sqlj; Owner: rickcharon
--

REVOKE ALL ON TABLE jar_entry FROM PUBLIC;
REVOKE ALL ON TABLE jar_entry FROM rickcharon;
GRANT ALL ON TABLE jar_entry TO rickcharon;
GRANT SELECT ON TABLE jar_entry TO PUBLIC;


--
-- Name: jar_repository; Type: ACL; Schema: sqlj; Owner: rickcharon
--

REVOKE ALL ON TABLE jar_repository FROM PUBLIC;
REVOKE ALL ON TABLE jar_repository FROM rickcharon;
GRANT ALL ON TABLE jar_repository TO rickcharon;
GRANT SELECT ON TABLE jar_repository TO PUBLIC;


--
-- Name: typemap_entry; Type: ACL; Schema: sqlj; Owner: rickcharon
--

REVOKE ALL ON TABLE typemap_entry FROM PUBLIC;
REVOKE ALL ON TABLE typemap_entry FROM rickcharon;
GRANT ALL ON TABLE typemap_entry TO rickcharon;
GRANT SELECT ON TABLE typemap_entry TO PUBLIC;


--
-- PostgreSQL database dump complete
--

